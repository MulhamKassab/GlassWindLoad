import axios from 'axios';

const instance = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
  headers: { 'Content-Type': 'application/json' }
});

export const calculate = async (payload) => {
  const { data } = await instance.post('/calculate', payload);
  return data;                 // { pdf_url, lr_result, cof:{…} }
};

export default instance;
