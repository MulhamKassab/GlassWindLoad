import './App.css';
import CalculatorPage from './pages/CalculatorPage';

function App() {
  return <CalculatorPage />;
}

export default App;
